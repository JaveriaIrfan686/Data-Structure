package com.company.myPackage;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class AppTest {



        /**
         * Rigorous Test :-)
         */
        @Test
        public void shouldAnswerWithTrue()
        {
            assertTrue( true );
        }

}
